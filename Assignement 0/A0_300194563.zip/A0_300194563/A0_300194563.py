# Course: IT1 1120
# Assignment number 1
# Family name, Given name: Makos
# Student number 300194563

print("hello world")
print(1+2*3)
print((1+2)*3)
print(2**10)
print(11/2)
print(sum([1,2,3,4,5]))
print(sum([25,12,1,40])/len([25,40,1,12]))
5*6

